export type TaskStatus = 'backlog' | 'todo' | 'running' | 'review' | 'done' | 'archived'

export type TaskType = 'CODEX' | 'SHELL' | 'MANUAL'

export type RunStatus = 'idle' | 'running' | 'completed' | 'canceled' | 'failed'

export interface LogEntry {
  id: string
  type: 'SYSTEM' | 'PLAN' | 'OUTPUT' | 'ERROR'
  title: string
  content: string
  timestamp: Date
}

export interface Task {
  id: string
  title: string
  description: string
  status: TaskStatus
  type: TaskType
  workspace: string
  createdAt: Date
  updatedAt: Date
  runStatus: RunStatus
  runId?: string
  logs: LogEntry[]
}

export interface Workspace {
  id: string
  name: string
  path: string
}

export const STATUS_CONFIG: Record<TaskStatus, { label: string; color: string }> = {
  backlog: { label: 'Backlog', color: 'muted' },
  todo: { label: 'Todo', color: 'info' },
  running: { label: 'Running', color: 'warning' },
  review: { label: 'Review', color: 'primary' },
  done: { label: 'Done', color: 'success' },
  archived: { label: 'Archived', color: 'muted' },
}

export const TYPE_CONFIG: Record<TaskType, { label: string; color: string }> = {
  CODEX: { label: 'CODEX', color: 'primary' },
  SHELL: { label: 'SHELL', color: 'warning' },
  MANUAL: { label: 'MANUAL', color: 'muted' },
}

export const RUN_STATUS_CONFIG: Record<RunStatus, { label: string; description: string }> = {
  idle: { label: 'idle', description: 'No active run' },
  running: { label: 'running', description: 'Task is currently executing' },
  completed: { label: 'completed', description: 'Task completed successfully' },
  canceled: { label: 'canceled', description: 'Task was stopped manually' },
  failed: { label: 'failed', description: 'Task encountered an error' },
}
