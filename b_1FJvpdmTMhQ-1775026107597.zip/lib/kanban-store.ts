import { Task, TaskStatus, Workspace, LogEntry } from './kanban-types'

// Mock data for demonstration
const mockLogs: LogEntry[] = [
  {
    id: '1',
    type: 'SYSTEM',
    title: 'Codex ACP',
    content: `[36;1mcodex app-server (WebSockets) [0m
  [2mlistening on: [0m  [32mws://127.0.0.1:65126 [0m
  [2mreadyz: [0m  [32mhttp://127.0.0.1:65126/readyz [0m
  [2mhealthz: [0m  [32mhttp://127.0.0.1:65126/healthz [0m
  [2mnote: [0m binds localhost only (use SSH port-forwarding for remote access)`,
    timestamp: new Date('2024-01-15T23:38:11'),
  },
  {
    id: '2',
    type: 'PLAN',
    title: 'Plan started',
    content: 'Planning started.',
    timestamp: new Date('2024-01-15T23:38:16'),
  },
  {
    id: '3',
    type: 'OUTPUT',
    title: 'Analysis complete',
    content: 'Identified 3 files requiring modification.',
    timestamp: new Date('2024-01-15T23:38:45'),
  },
]

const mockTasks: Task[] = [
  {
    id: '1',
    title: '移除shell的支持',
    description: 'No description',
    status: 'review',
    type: 'CODEX',
    workspace: 'Workhorse',
    createdAt: new Date(Date.now() - 11 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 11 * 60 * 60 * 1000),
    runStatus: 'canceled',
    runId: '98873fb1-fcf1-4e10-88da-493910be5705',
    logs: mockLogs,
  },
  {
    id: '2',
    title: 'rerun log follow smoke',
    description: 'verify latest run selection',
    status: 'review',
    type: 'SHELL',
    workspace: 'Workhorse',
    createdAt: new Date(Date.now() - 11 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 11 * 60 * 60 * 1000),
    runStatus: 'idle',
    logs: [],
  },
  {
    id: '3',
    title: 'review rerun selection smoke',
    description: 'verify latest run logs remain visible',
    status: 'review',
    type: 'SHELL',
    workspace: 'Workhorse',
    createdAt: new Date(Date.now() - 11 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 11 * 60 * 60 * 1000),
    runStatus: 'idle',
    logs: [],
  },
  {
    id: '4',
    title: '压缩前端页面 header',
    description: 'No description',
    status: 'done',
    type: 'CODEX',
    workspace: 'Workhorse',
    createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 12 * 60 * 60 * 1000),
    runStatus: 'completed',
    logs: [],
  },
  {
    id: '5',
    title: 'Task details 这个应该收起来，做成一个独立的task detail 页面，点击卡面可以进入这个页面',
    description: 'No description',
    status: 'done',
    type: 'CODEX',
    workspace: 'Workhorse',
    createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 12 * 60 * 60 * 1000),
    runStatus: 'completed',
    logs: mockLogs,
  },
]

const mockWorkspaces: Workspace[] = [
  { id: '1', name: 'Workhorse', path: '/Users/chenxin/Projects/workhorse' },
  { id: '2', name: 'Normalizer', path: '/Users/chenxin/Projects/text-normalizer' },
]

export function getTasks(): Task[] {
  return mockTasks
}

export function getTaskById(id: string): Task | undefined {
  return mockTasks.find(task => task.id === id)
}

export function getTasksByStatus(status: TaskStatus): Task[] {
  return mockTasks.filter(task => task.status === status)
}

export function getWorkspaces(): Workspace[] {
  return mockWorkspaces
}

export function formatTimeAgo(date: Date): string {
  const now = new Date()
  const diffMs = now.getTime() - date.getTime()
  const diffMins = Math.floor(diffMs / 60000)
  const diffHours = Math.floor(diffMs / 3600000)
  const diffDays = Math.floor(diffMs / 86400000)

  if (diffMins < 1) return 'just now'
  if (diffMins < 60) return `${diffMins}m ago`
  if (diffHours < 24) return `${diffHours}h ago`
  return `${diffDays}d ago`
}
