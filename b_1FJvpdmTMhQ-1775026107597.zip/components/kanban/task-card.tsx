"use client"

import { Task, TYPE_CONFIG } from "@/lib/kanban-types"
import { formatTimeAgo } from "@/lib/kanban-store"
import { cn } from "@/lib/utils"

interface TaskCardProps {
  task: Task
  onClick: () => void
}

export function TaskCard({ task, onClick }: TaskCardProps) {
  const typeConfig = TYPE_CONFIG[task.type]

  return (
    <div
      onClick={onClick}
      className="group cursor-pointer border border-border bg-card p-3 transition-colors hover:border-primary hover:bg-card/80"
    >
      <div className="flex items-start justify-between gap-2">
        <h3 className="text-sm font-medium leading-tight line-clamp-2">
          {task.title}
        </h3>
        <span
          className={cn(
            "shrink-0 rounded-none px-1.5 py-0.5 text-[10px] font-mono uppercase tracking-wider",
            typeConfig.color === "primary" && "bg-primary/20 text-primary",
            typeConfig.color === "warning" && "bg-warning/20 text-warning",
            typeConfig.color === "muted" && "bg-muted text-muted-foreground"
          )}
        >
          {typeConfig.label}
        </span>
      </div>

      <p className="mt-1.5 text-xs text-muted-foreground line-clamp-2">
        {task.description || "No description"}
      </p>

      <div className="mt-3 flex items-center gap-2 text-[10px]">
        <span className="text-muted-foreground">{task.workspace}</span>
        <span
          className={cn(
            "rounded-none px-1 py-0.5 font-mono uppercase",
            task.runStatus === "idle" && "bg-muted text-muted-foreground",
            task.runStatus === "running" && "bg-warning/20 text-warning",
            task.runStatus === "completed" && "bg-success/20 text-success",
            task.runStatus === "canceled" && "bg-destructive/20 text-destructive",
            task.runStatus === "failed" && "bg-destructive/20 text-destructive"
          )}
        >
          {task.runStatus === "idle" ? "NOT CREATED" : task.runStatus.toUpperCase()}
        </span>
        <span className="ml-auto text-muted-foreground">
          {formatTimeAgo(task.updatedAt)}
        </span>
      </div>
    </div>
  )
}
