"use client"

import { Search, X, Plus, RefreshCw } from "lucide-react"
import { Button } from "@/components/ui/button"
import { ThemeToggle } from "@/components/theme-toggle"

interface KanbanHeaderProps {
  searchQuery: string
  onSearchChange: (query: string) => void
  taskCount: number
  lastUpdated: string
}

export function KanbanHeader({
  searchQuery,
  onSearchChange,
  taskCount,
  lastUpdated,
}: KanbanHeaderProps) {
  return (
    <header className="border-b border-border bg-card">
      <div className="flex items-center justify-between h-12 px-4">
        {/* Left: Logo and status */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono uppercase tracking-widest text-primary font-semibold">
              WORKHORSE
            </span>
            <span className="text-muted-foreground/50">|</span>
            <span className="text-sm text-muted-foreground">Local Kanban</span>
          </div>
          
          <div className="flex items-center gap-3 text-xs text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <span className="size-1.5 rounded-full bg-success" />
              Ready
            </span>
            <span>{taskCount} tasks</span>
            <span>Updated {lastUpdated}</span>
          </div>
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-2">
          {/* Search */}
          <div className="relative flex items-center">
            <Search className="absolute left-2 size-3.5 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="h-7 w-40 rounded-none border border-border bg-background pl-7 pr-7 text-xs placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
            />
            {searchQuery && (
              <button
                onClick={() => onSearchChange("")}
                className="absolute right-2 text-muted-foreground hover:text-foreground"
              >
                <X className="size-3" />
              </button>
            )}
          </div>

          <select className="h-7 rounded-none border border-border bg-background px-2 text-xs focus:border-primary focus:outline-none">
            <option>All workspaces</option>
            <option>Workhorse</option>
            <option>Normalizer</option>
          </select>
          
          <Button variant="ghost" size="sm" className="h-7 px-2 rounded-none">
            <RefreshCw className="size-3.5" />
          </Button>
          
          <Button size="sm" className="h-7 rounded-none gap-1 text-xs">
            <Plus className="size-3" />
            New
          </Button>
          
          <ThemeToggle />
        </div>
      </div>
    </header>
  )
}
