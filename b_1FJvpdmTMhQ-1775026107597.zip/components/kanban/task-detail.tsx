"use client"

import { ArrowLeft, Square, FolderX, Trash2, Copy } from "lucide-react"
import { Task, TYPE_CONFIG, STATUS_CONFIG } from "@/lib/kanban-types"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface TaskDetailProps {
  task: Task
  onBack: () => void
}

export function TaskDetail({ task, onBack }: TaskDetailProps) {
  const typeConfig = TYPE_CONFIG[task.type]
  const statusConfig = STATUS_CONFIG[task.status]

  const formatTimeAgo = (date: Date) => {
    const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000)
    if (seconds < 60) return "just now"
    const minutes = Math.floor(seconds / 60)
    if (minutes < 60) return `${minutes}m ago`
    const hours = Math.floor(minutes / 60)
    if (hours < 24) return `${hours}h ago`
    return `${Math.floor(hours / 24)}d ago`
  }

  return (
    <div className="flex h-full flex-col">
      {/* Compact sub-header */}
      <div className="flex items-center justify-between border-b border-border bg-card h-10 px-4">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={onBack}
            className="h-7 rounded-none gap-1.5 px-2 text-xs"
          >
            <ArrowLeft className="size-3" />
            Back to board
          </Button>
          <span className="text-muted-foreground/40">|</span>
          <span className="text-[10px] font-mono uppercase text-muted-foreground">
            WORKSPACE {task.workspace.toUpperCase()}
          </span>
          <span
            className={cn(
              "rounded-none px-1.5 py-0.5 text-[10px] font-mono uppercase",
              statusConfig.color === "primary" && "bg-primary/20 text-primary",
              statusConfig.color === "success" && "bg-success/20 text-success",
              statusConfig.color === "warning" && "bg-warning/20 text-warning",
              statusConfig.color === "info" && "bg-info/20 text-info",
              statusConfig.color === "muted" && "bg-muted text-muted-foreground"
            )}
          >
            {statusConfig.label}
          </span>
          <span
            className={cn(
              "rounded-none px-1.5 py-0.5 text-[10px] font-mono uppercase",
              typeConfig.color === "primary" && "bg-primary/20 text-primary",
              typeConfig.color === "warning" && "bg-warning/20 text-warning",
              typeConfig.color === "muted" && "bg-muted text-muted-foreground"
            )}
          >
            {task.type}
          </span>
          <span
            className={cn(
              "rounded-none px-1.5 py-0.5 text-[10px] font-mono uppercase",
              task.runStatus === "idle" && "bg-muted text-muted-foreground",
              task.runStatus === "running" && "bg-warning/20 text-warning",
              task.runStatus === "completed" && "bg-success/20 text-success",
              (task.runStatus === "canceled" || task.runStatus === "failed") && "bg-destructive/20 text-destructive"
            )}
          >
            {task.runStatus === "idle" ? "READY" : task.runStatus.toUpperCase()}
          </span>
        </div>
        <Button variant="ghost" size="sm" className="h-7 rounded-none text-destructive hover:text-destructive hover:bg-destructive/10 text-xs px-2">
          <Trash2 className="size-3 mr-1" />
          Delete
        </Button>
      </div>

      {/* Task title bar */}
      <div className="flex items-center justify-between border-b border-border bg-card px-4 py-3">
        <div>
          <div className="text-[10px] font-mono uppercase tracking-widest text-primary mb-1">
            TASK DETAILS
          </div>
          <h1 className="text-xl font-semibold tracking-tight">{task.title}</h1>
          <p className="text-xs text-muted-foreground mt-0.5">{task.workspace}</p>
        </div>
        <div className="flex items-center gap-2">
          {task.runStatus === "running" && (
            <Button variant="outline" size="sm" className="h-7 rounded-none gap-1 text-xs">
              <Square className="size-3" />
              Stop
            </Button>
          )}
          <Button variant="outline" size="sm" className="h-7 rounded-none gap-1 text-xs">
            <FolderX className="size-3" />
            Remove worktree
          </Button>
        </div>
      </div>

      {/* Two column layout */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left column - Task info */}
        <div className="w-[360px] flex-shrink-0 overflow-y-auto border-r border-border p-4 space-y-4">
          {/* Description */}
          <Section title="Description">
            <p className="text-sm text-muted-foreground leading-relaxed">
              {task.description || "No description provided."}
            </p>
          </Section>

          {/* Run status */}
          <Section title="Run status">
            <div className="flex items-start justify-between">
              <div>
                <div className="font-medium text-sm capitalize">{task.runStatus}</div>
                <div className="text-xs text-muted-foreground mt-0.5">
                  {task.runStatus === "running" && "This task is actively executing and streaming fresh output."}
                  {task.runStatus === "idle" && "No active run"}
                  {task.runStatus === "completed" && "Task completed successfully"}
                  {task.runStatus === "canceled" && "Task was stopped manually"}
                  {task.runStatus === "failed" && "Task encountered an error"}
                </div>
              </div>
              <span className={cn(
                "rounded-none px-1.5 py-0.5 text-[10px] font-mono uppercase",
                typeConfig.color === "primary" && "bg-primary/20 text-primary",
                typeConfig.color === "warning" && "bg-warning/20 text-warning",
                typeConfig.color === "muted" && "bg-muted text-muted-foreground"
              )}>
                {task.type}
              </span>
            </div>
            {task.runId && (
              <div className="mt-3 pt-3 border-t border-border">
                <div className="text-[10px] font-mono uppercase tracking-wider text-primary mb-1">VIEWING RUN</div>
                <div className="font-mono text-xs break-all">{task.runId}</div>
              </div>
            )}
          </Section>

          {/* Snapshot */}
          <Section title="Snapshot">
            <div className="grid grid-cols-2 gap-3">
              <DataField label="STATUS" value={task.runStatus} />
              <DataField label="UPDATED" value={formatTimeAgo(task.updatedAt)} />
              <DataField label="CREATED" value={formatTimeAgo(task.createdAt)} />
              <DataField label="LAST RUN" value={task.runId ? task.runId.substring(0, 8) + "..." : "-"} mono />
            </div>
          </Section>

          {/* Worktree */}
          <Section title="Worktree">
            <div className="grid grid-cols-2 gap-3">
              <DataField label="STATUS" value="Ready" />
              <DataField label="BASE REF" value="origin/main" mono />
              <DataField label="BRANCH" value={`task/${task.id.substring(0, 8)}`} mono className="col-span-2" />
              <DataField label="LAST SYNC" value={formatTimeAgo(task.updatedAt)} />
            </div>
            <div className="mt-3 pt-3 border-t border-border">
              <div className="text-[10px] font-mono uppercase tracking-wider text-primary mb-1">PATH</div>
              <div className="font-mono text-xs text-muted-foreground break-all">
                /Users/workspace/.workhorse-worktrees/{task.id}
              </div>
            </div>
          </Section>

          {/* Runner config */}
          <Section title="Runner config">
            <div className="text-[10px] font-mono uppercase tracking-wider text-primary mb-1">PROMPT</div>
            <div className="border border-border bg-muted/30 p-2">
              <p className="text-xs text-muted-foreground">请完成用户请求的任务。</p>
            </div>
          </Section>

          {/* Run history */}
          <Section title="Run history">
            <div className="space-y-0 divide-y divide-border border border-border">
              <div className="flex items-center justify-between px-2 py-1.5 text-xs">
                <span>Running</span>
                <span className="text-muted-foreground">{formatTimeAgo(task.updatedAt)}</span>
              </div>
              <div className="flex items-center justify-between px-2 py-1.5 text-xs">
                <span>Canceled</span>
                <span className="text-muted-foreground">{formatTimeAgo(task.createdAt)}</span>
              </div>
            </div>
          </Section>
        </div>

        {/* Right column - Live log */}
        <div className="flex-1 flex flex-col overflow-hidden bg-muted/20">
          <div className="flex items-center justify-between px-4 py-2 border-b border-border bg-card">
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-semibold">Live log</h2>
              <span className="text-[10px] font-mono text-muted-foreground uppercase">
                {task.logs.length} STREAM
              </span>
            </div>
            <Button variant="ghost" size="sm" className="h-6 rounded-none text-xs gap-1 px-2">
              <Copy className="size-3" />
              Copy
            </Button>
          </div>
          
          {task.runId && (
            <div className="px-4 py-2 text-xs text-muted-foreground border-b border-border bg-card">
              Viewing running run <span className="font-mono text-primary">{task.runId}</span>
            </div>
          )}

          <div className="flex-1 overflow-y-auto p-2">
            {task.logs.length === 0 ? (
              <div className="flex items-center justify-center h-full text-sm text-muted-foreground">
                No logs available
              </div>
            ) : (
              <div className="space-y-1">
                <div className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground px-2 py-1">
                  OUTPUT STREAM
                </div>
                {task.logs.map((log) => (
                  <LogEntry key={log.id} log={log} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="border border-border bg-card">
      <div className="px-3 py-2 border-b border-border">
        <h3 className="text-xs font-semibold">{title}</h3>
      </div>
      <div className="p-3">{children}</div>
    </div>
  )
}

function DataField({ 
  label, 
  value, 
  mono = false,
  className 
}: { 
  label: string; 
  value: string; 
  mono?: boolean;
  className?: string 
}) {
  return (
    <div className={className}>
      <div className="text-[10px] font-mono uppercase tracking-wider text-primary mb-0.5">{label}</div>
      <div className={cn("text-sm", mono && "font-mono text-xs")}>{value}</div>
    </div>
  )
}

function LogEntry({ log }: { log: Task["logs"][0] }) {
  return (
    <div className="border border-border bg-card p-2">
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2 flex-1 min-w-0">
          <span
            className={cn(
              "rounded-none px-1.5 py-0.5 text-[10px] font-mono uppercase flex-shrink-0",
              log.type === "SYSTEM" && "bg-muted text-muted-foreground",
              log.type === "PLAN" && "bg-primary/20 text-primary",
              log.type === "OUTPUT" && "bg-success/20 text-success",
              log.type === "ERROR" && "bg-destructive/20 text-destructive"
            )}
          >
            {log.type}
          </span>
          <span className="font-medium text-xs truncate">{log.title}</span>
        </div>
        <span className="text-[10px] text-muted-foreground font-mono flex-shrink-0">
          {log.timestamp.toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit",
            second: "2-digit",
          })}
        </span>
      </div>
      <pre className="mt-1.5 overflow-x-auto whitespace-pre-wrap font-mono text-xs text-muted-foreground leading-relaxed">
        {log.content}
      </pre>
    </div>
  )
}
