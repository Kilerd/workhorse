"use client"

import { Task, TaskStatus } from "@/lib/kanban-types"
import { KanbanColumn } from "./kanban-column"

const COLUMNS: TaskStatus[] = ['backlog', 'todo', 'running', 'review', 'done', 'archived']

interface KanbanBoardProps {
  tasks: Task[]
  onTaskClick: (taskId: string) => void
}

export function KanbanBoard({ tasks, onTaskClick }: KanbanBoardProps) {
  const getTasksByStatus = (status: TaskStatus) => {
    return tasks.filter((task) => task.status === status)
  }

  return (
    <div className="flex h-full overflow-x-auto">
      {COLUMNS.map((status) => (
        <KanbanColumn
          key={status}
          status={status}
          tasks={getTasksByStatus(status)}
          onTaskClick={onTaskClick}
        />
      ))}
    </div>
  )
}
