"use client"

import { Task, TaskStatus, STATUS_CONFIG } from "@/lib/kanban-types"
import { TaskCard } from "./task-card"

interface KanbanColumnProps {
  status: TaskStatus
  tasks: Task[]
  onTaskClick: (taskId: string) => void
}

export function KanbanColumn({ status, tasks, onTaskClick }: KanbanColumnProps) {
  const config = STATUS_CONFIG[status]

  return (
    <div className="flex h-full min-w-[260px] flex-col border-r border-border last:border-r-0">
      <div className="flex items-center justify-between border-b border-border bg-muted/30 px-3 py-2">
        <h2 className="text-sm font-semibold">{config.label}</h2>
        <span className="text-xs text-muted-foreground">{tasks.length} cards</span>
      </div>

      <div className="flex-1 overflow-y-auto p-2">
        <div className="flex flex-col gap-2">
          {tasks.map((task) => (
            <TaskCard
              key={task.id}
              task={task}
              onClick={() => onTaskClick(task.id)}
            />
          ))}
        </div>
      </div>
    </div>
  )
}
