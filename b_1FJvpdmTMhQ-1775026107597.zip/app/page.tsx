"use client"

import { useState, useMemo } from "react"
import { KanbanHeader } from "@/components/kanban/kanban-header"
import { KanbanBoard } from "@/components/kanban/kanban-board"
import { TaskDetail } from "@/components/kanban/task-detail"
import { getTasks, getTaskById } from "@/lib/kanban-store"

export default function KanbanPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(null)

  const tasks = getTasks()

  const filteredTasks = useMemo(() => {
    if (!searchQuery) return tasks
    const query = searchQuery.toLowerCase()
    return tasks.filter(
      (task) =>
        task.title.toLowerCase().includes(query) ||
        task.description.toLowerCase().includes(query) ||
        task.workspace.toLowerCase().includes(query)
    )
  }, [tasks, searchQuery])

  const selectedTask = selectedTaskId ? getTaskById(selectedTaskId) : null

  const handleTaskClick = (taskId: string) => {
    setSelectedTaskId(taskId)
  }

  const handleBackToBoard = () => {
    setSelectedTaskId(null)
  }

  return (
    <div className="flex h-screen flex-col bg-background">
      <KanbanHeader
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        taskCount={tasks.length}
        lastUpdated="just now"
      />

      <main className="flex-1 overflow-hidden">
        {selectedTask ? (
          <TaskDetail task={selectedTask} onBack={handleBackToBoard} />
        ) : (
          <KanbanBoard tasks={filteredTasks} onTaskClick={handleTaskClick} />
        )}
      </main>
    </div>
  )
}
