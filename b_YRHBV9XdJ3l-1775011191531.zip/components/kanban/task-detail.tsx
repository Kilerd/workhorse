"use client"

import { useState } from "react"
import { ArrowLeft, Play, Check, Trash2 } from "lucide-react"
import { Task, TYPE_CONFIG, STATUS_CONFIG, RUN_STATUS_CONFIG } from "@/lib/kanban-types"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { cn } from "@/lib/utils"

interface TaskDetailProps {
  task: Task
  onBack: () => void
}

export function TaskDetail({ task, onBack }: TaskDetailProps) {
  const [activeTab, setActiveTab] = useState("overview")
  const typeConfig = TYPE_CONFIG[task.type]
  const statusConfig = STATUS_CONFIG[task.status]
  const runConfig = RUN_STATUS_CONFIG[task.runStatus]

  return (
    <div className="flex h-full flex-col">
      {/* Back button */}
      <div className="border-b border-border bg-card px-4 py-3">
        <Button
          variant="outline"
          size="sm"
          onClick={onBack}
          className="rounded-none gap-1.5"
        >
          <ArrowLeft className="size-3" />
          Back to board
        </Button>
      </div>

      {/* Task header */}
      <div className="border-b border-border bg-card p-4">
        <div className="flex items-start justify-between">
          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-2">
              <span className="rounded-none bg-muted px-2 py-0.5 text-[10px] font-mono uppercase">
                Workspace {task.workspace}
              </span>
              <span
                className={cn(
                  "rounded-none px-2 py-0.5 text-[10px] font-mono uppercase",
                  statusConfig.color === "primary" && "bg-primary/20 text-primary",
                  statusConfig.color === "success" && "bg-success/20 text-success",
                  statusConfig.color === "warning" && "bg-warning/20 text-warning",
                  statusConfig.color === "info" && "bg-info/20 text-info",
                  statusConfig.color === "muted" && "bg-muted text-muted-foreground"
                )}
              >
                {statusConfig.label}
              </span>
              <span
                className={cn(
                  "rounded-none px-2 py-0.5 text-[10px] font-mono uppercase",
                  task.runStatus === "idle" && "bg-muted text-muted-foreground",
                  task.runStatus === "running" && "bg-warning/20 text-warning",
                  task.runStatus === "completed" && "bg-success/20 text-success",
                  task.runStatus === "canceled" && "bg-destructive/20 text-destructive",
                  task.runStatus === "failed" && "bg-destructive/20 text-destructive"
                )}
              >
                {task.runStatus === "idle" ? "NOT CREATED" : task.runStatus.toUpperCase()}
              </span>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-xs font-mono uppercase tracking-widest text-muted-foreground">
                TASK DETAILS
              </span>
            </div>
            <h1 className="text-3xl font-semibold tracking-tight">{task.title}</h1>
            <p className="text-sm text-muted-foreground">{task.workspace}</p>
          </div>

          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="rounded-none gap-1.5">
              <Play className="size-3" />
              Move to Todo
            </Button>
            <Button variant="outline" size="sm" className="rounded-none gap-1.5">
              <Check className="size-3" />
              Mark Done
            </Button>
            <Button variant="destructive" size="sm" className="rounded-none gap-1.5">
              <Trash2 className="size-3" />
              Delete
            </Button>
          </div>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-4">
          <TabsList className="rounded-none bg-transparent p-0 h-auto">
            <TabsTrigger
              value="overview"
              className="rounded-none border border-border bg-secondary data-[state=active]:bg-card data-[state=active]:border-primary px-4 py-2"
            >
              Overview
            </TabsTrigger>
            <TabsTrigger
              value="logs"
              className="rounded-none border border-border bg-secondary data-[state=active]:bg-card data-[state=active]:border-primary px-4 py-2 -ml-px"
            >
              Logs
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsContent value="overview" className="mt-0">
            {/* Run Status Section */}
            <div className="border border-border bg-card">
              <div className="border-b border-border px-4 py-2">
                <h2 className="text-sm font-semibold">Run status</h2>
              </div>
              <div className="p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="font-medium">{runConfig.label}</div>
                    <div className="text-sm text-muted-foreground">
                      {runConfig.description}
                    </div>
                  </div>
                  <span
                    className={cn(
                      "rounded-none px-2 py-0.5 text-xs font-mono",
                      typeConfig.color === "primary" && "bg-primary/20 text-primary",
                      typeConfig.color === "warning" && "bg-warning/20 text-warning",
                      typeConfig.color === "muted" && "bg-muted text-muted-foreground"
                    )}
                  >
                    {task.type.toLowerCase()}
                  </span>
                </div>

                {task.runId && (
                  <div className="mt-4 border-t border-border pt-4 text-sm">
                    <div className="text-muted-foreground">
                      Viewing {task.runStatus} run{" "}
                      <span className="font-mono text-primary">{task.runId}</span>
                    </div>
                    {task.runStatus === "canceled" && (
                      <p className="mt-1 text-muted-foreground">
                        This run was canceled. That usually means it was stopped
                        manually, or the server restarted while the task was running.
                      </p>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Live Log Section */}
            <div className="mt-4 border border-border bg-card">
              <div className="border-b border-border px-4 py-2">
                <h2 className="text-sm font-semibold">Live log</h2>
              </div>
              <div className="max-h-96 overflow-y-auto p-2">
                {task.logs.length === 0 ? (
                  <div className="p-4 text-center text-sm text-muted-foreground">
                    No logs available
                  </div>
                ) : (
                  <div className="flex flex-col gap-2">
                    {task.logs.map((log) => (
                      <LogEntry key={log.id} log={log} />
                    ))}
                  </div>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="logs" className="mt-0">
            <div className="border border-border bg-card">
              <div className="border-b border-border px-4 py-2">
                <h2 className="text-sm font-semibold">Full Logs</h2>
              </div>
              <div className="max-h-[600px] overflow-y-auto p-2">
                {task.logs.length === 0 ? (
                  <div className="p-4 text-center text-sm text-muted-foreground">
                    No logs available
                  </div>
                ) : (
                  <div className="flex flex-col gap-2">
                    {task.logs.map((log) => (
                      <LogEntry key={log.id} log={log} />
                    ))}
                  </div>
                )}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

function LogEntry({ log }: { log: Task["logs"][0] }) {
  return (
    <div className="border border-border bg-surface p-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span
            className={cn(
              "rounded-none px-1.5 py-0.5 text-[10px] font-mono uppercase",
              log.type === "SYSTEM" && "bg-muted text-muted-foreground",
              log.type === "PLAN" && "bg-primary/20 text-primary",
              log.type === "OUTPUT" && "bg-success/20 text-success",
              log.type === "ERROR" && "bg-destructive/20 text-destructive"
            )}
          >
            {log.type}
          </span>
          <span className="font-medium text-sm">{log.title}</span>
        </div>
        <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
          <span className="rounded-none bg-muted px-1.5 py-0.5 font-mono uppercase">
            SYSTEM
          </span>
          <span>
            {log.timestamp.toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
              second: "2-digit",
            })}
          </span>
        </div>
      </div>
      <pre className="mt-2 overflow-x-auto whitespace-pre-wrap font-mono text-xs text-muted-foreground">
        {log.content}
      </pre>
    </div>
  )
}
